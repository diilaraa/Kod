﻿// Geliştirici: Dilara Top
// Ögrenci No: B221200573
// Ödev NO: 2
// Ödev Açıklama: Matris oluşturma, Matris işlmeleri ve Şifreleme

#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <locale.h>
#include <iomanip>
#include <time.h>

using namespace std;

const int SATİR = 5;
const int SUTUN = 5;

int main()
{
	int A[SATİR][SUTUN]{};
	cout << "A Matrisi:" << endl;

	for (int i = 0; i < SATİR; i++)
		for (int j = 0; j < SUTUN; j++)
			A[i][j] = rand() % 10 + 1;

	for (int i = 0; i < SATİR; i++) {
		for (int j = 0; j < SUTUN; j++)
			cout << setw(5) << A[i][j];
		cout << endl;
	}

	int B[SATİR][SUTUN]{};
	cout << "B Matrisi:" << endl;

	for (int i = 0; i < SATİR; i++)
		for (int j = 0; j < SUTUN; j++)
			B[i][j] = rand() % 10 + 1;

	for (int i = 0; i < SATİR; i++) {
		for (int j = 0; j < SUTUN; j++)
			cout << setw(5) << B[i][j];
		cout << endl;
	}


	int x, y, temp;
	cout << "Satir numarasini giriniz:" << endl;
	cin >> x;
	cout << "Sutun numarasini giriniz:" << endl;
	cin >> y;
	for (int i = 0; i < 5; i++) {
		temp = A[x - 1][i];
		A[x - 1][i] = B[x - 1][i];
		B[x - 1][i] = temp;
		if (x - 1 == i)
			continue;
		temp = A[i][y - 1];
		A[i][y - 1] = B[i][y - 1];
		B[i][y - 1] = temp;
	}

	cout << "Degisim Sonrasi A Matrisi :" << endl;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			cout << "\t" << A[i][j];
		}
		cout << endl;
	}

	cout << "Degisim Sonrasi B Matrisi :" << endl;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			cout << "\t" << B[i][j];
		}
		cout << endl;
	}


	int C[5][5]{};
	cout << "A*B Matrisi:" << endl;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			C[i][j] = 0;
			for (int k = 0; k < 5; k++) {
				C[i][j] += A[i][k] * B[k][j];

			}
			cout << "\t" << C[i][j];
		}
		cout << endl;
	}


	setlocale(LC_ALL, "Turkish");
	string cevap;
	string E = "E";
	string H = "H";
	cout << "Devam etmek istiyor musunuz?(E/H):";
	cin >> cevap;
	while (cevap == E) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				A[i][j] = rand() % 10 + 1;
			}
		}
		cout << "Matris A:" << '\n';
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++)
				cout << A[i][j] << '\t';
			cout << '\n';

		}
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				B[i][j] = rand() % 10 + 1;
			}
		}
		cout << "Matris B:" << '\n';
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++)
				cout << B[i][j] << '\t';
			cout << '\n';
		}
		cout << "Değiştirilecek satır sayısını giriniz (1'den 5'e kadar):";
		cin >> x;
		cout << "Değiştirilecek sütun sayısını giriniz (1'den 5'e kadar):";
		cin >> y;
		for (int i = 0; i < 5; i++) {
			temp = A[x - 1][i];
			A[x - 1][i] = B[x - 1][i];
			B[x - 1][i] = temp;
			if (x - 1 == i)
				continue;
			temp = A[i][y - 1];
			A[i][y - 1] = B[i][y - 1];
			B[i][y - 1] = temp;
		}

		cout << "Değişim Sonrası:" << endl;
		cout << "A Matrisi:" << endl;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				cout << "\t" << A[i][j];
			}
			cout << endl;
		}
		cout << "B Matrisi:" << endl;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				cout << "\t" << B[i][j];
			}
			cout << endl;
		}
		cout << "A*B Çarpımı:" << endl;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				C[i][j] = 0;
				for (int k = 0; k < 5; k++) {
					C[i][j] += A[i][k] * B[k][j];

				}
				cout << "\t" << C[i][j];
			}
			cout << endl;
		}
		cout << "Devam etmek istiyor musunuz? (E/H):";
		cin >> cevap;
	}
	if (cevap == H) {
		cout << "Hoşçakalın..." << endl;
	}
	system("pause");
	return 0;
}




